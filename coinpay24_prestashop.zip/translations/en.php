
<?php
global $_MODULE;
$_MODULE = array();
$_MODULE['<{coinpay24}prestashop>coinpay24_2b6e7b9ac7e1a8a9a356da5ed774fdfc'] = 'Accept payments using CoinPay24 cryptocurrency gateway.';
?>
